import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'recaudacionms-tributaria-declapago-rentapp-frontend-sharedlib';
  monto: number = 10.7888;
  objetoPrb = {
    monto: 123.456,
    numeroCasilla: 987,
    textoCasilla: 'Ayuda de prueba'
  }

  salir(){
    alert("MOSTRANDO MENSAJE SALIR");
  }
  abrirAsistente(){
    alert('Abriendo asistente');
  }
  enviar(){
    alert('Monto actualizado: ' + this.objetoPrb.monto);
  }
}
