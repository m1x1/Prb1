import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'lib-casilla-renta',
  templateUrl: './casilla-renta.component.html',
  styleUrls: ['./casilla-renta.component.css']
})
export class CasillaRentaComponent implements OnInit {
  @Input() tipo: number;
  @Input() numCasilla: string;
  @Input() textoPopover: string;
  @Input() monto: number;
  @Output() montoChange: EventEmitter<number> = new EventEmitter();
  @Output() abrirAsistente: EventEmitter<boolean> = new EventEmitter();

  mostrarNumero: boolean =  false;
  mostrarPopover: boolean =  false;

  constructor() { }

  ngOnInit() {
    this.mostrarNumero = this.numCasilla != null && this.numCasilla != undefined;
    this.mostrarPopover = this.textoPopover != null && this.textoPopover != undefined;
  }

  escucharEventoAsistente(){
    this.abrirAsistente.emit(true);
  }

  cambiarMonto(){
    console.log("Entraaa: " + this.monto);
    this.montoChange.emit(this.monto);
  }
}
