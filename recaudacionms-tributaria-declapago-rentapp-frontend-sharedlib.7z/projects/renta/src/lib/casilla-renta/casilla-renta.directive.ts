import { Directive, ElementRef, Input, OnInit, Renderer2, Output, EventEmitter, HostListener } from '@angular/core';

@Directive({
  selector: '[appCasillaRenta]'
})
export class CasillaRentaDirective implements OnInit {
  @Input() appCasillaRentaTipo: number;
  @Output() eventoAsistente: EventEmitter<boolean> = new EventEmitter();
  @HostListener('click') onClick(){
    if(this.appCasillaRentaTipo == 2)
      this.eventoAsistente.emit(true);
  }

  constructor(private elem: ElementRef, private renderer: Renderer2) { }

  ngOnInit(){
    this.renderer.setAttribute(this.elem.nativeElement, 'placeholder', "S/ 0");
    let claseCss = "";
    switch (this.appCasillaRentaTipo) {
      case 0:
          //claseCss = "Casilla-rellenar";
          break;
      case 1:
          claseCss = "Casilla-generada";
          this.renderer.setAttribute(this.elem.nativeElement, "readonly", "readonly");
          break;
      case 2:
          claseCss = "Activar-Asistente";
          this.renderer.setAttribute(this.elem.nativeElement, "readonly", "readonly");
          break;
      default:
          console.log("Tipo de casilla es incorrecto. Valores válidos: 0 - casilla monto, 1- casilla calculada, 2 - casilla con asistente");
          break;
        }
    this.renderer.setAttribute(this.elem.nativeElement, 'class', claseCss + " form-control texto-derecha");
  }

}
