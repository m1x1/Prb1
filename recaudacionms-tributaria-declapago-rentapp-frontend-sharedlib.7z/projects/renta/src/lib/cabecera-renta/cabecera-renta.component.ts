import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'lib-cabecera-renta',
  templateUrl: './cabecera-renta.component.html',
  styleUrls: ['./cabecera-renta.component.css']
})
export class CabeceraRentaComponent implements OnInit {
  @Input() nombreContribuyente: string;
  @Input() paso: number;
  @Output() eventoSalir: EventEmitter<boolean> = new EventEmitter();
  paso1: boolean = false;
  paso2: boolean = false;
  paso3: boolean = false;
  fecha: Date;

  constructor() { }

  ngOnInit() {
    setInterval(() => {
      this.fecha = new Date();
    }, 1);
    if(this.paso != null && this.paso != undefined){
      this.paso1 = this.paso == 1;
      this.paso2 = this.paso == 2;
      this.paso3 = this.paso == 3;
    }
  }

  ejecutarMetodoSalir(){
    this.eventoSalir.emit(true);
  }
}
