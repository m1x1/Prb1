import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CabeceraRentaComponent } from './cabecera-renta.component';

describe('CabeceraRentaComponent', () => {
  let component: CabeceraRentaComponent;
  let fixture: ComponentFixture<CabeceraRentaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CabeceraRentaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CabeceraRentaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
