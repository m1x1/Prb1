import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-renta',
  template: `
    <p>
      renta works!
    </p>
  `,
  styles: []
})
export class RentaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
