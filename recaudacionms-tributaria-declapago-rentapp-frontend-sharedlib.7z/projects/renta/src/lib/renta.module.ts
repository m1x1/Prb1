import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RentaComponent } from './renta.component';
import { CabeceraRentaComponent } from './cabecera-renta/cabecera-renta.component';
import { CasillaRentaComponent } from './casilla-renta/casilla-renta.component';
import { CasillaRentaDirective } from './casilla-renta/casilla-renta.directive';
import { BrowserModule } from '@angular/platform-browser';
import {NgxMaskModule} from 'ngx-mask'
import { AngularFontAwesomeModule } from 'angular-font-awesome';

@NgModule({
  declarations: [RentaComponent, CabeceraRentaComponent, CasillaRentaComponent, CasillaRentaDirective],
  imports: [
    BrowserModule,
    NgbModule.forRoot(),
    NgxMaskModule.forRoot(),
    AngularFontAwesomeModule,
    FormsModule,
    ReactiveFormsModule
  ],
  exports: [RentaComponent, CabeceraRentaComponent, CasillaRentaComponent, CasillaRentaDirective]
})
export class RentaModule { }
