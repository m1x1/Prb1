## Transpilar
Posicionarse en la ruta del proyecto y ejecutar:

```shell
npm run build:lib
```
## Cómo usar
- Copiar la librería **renta** en el directorio **node_modules** del proyecto en el que la utilizarán.
- Agregar la librería **renta** en el archivo **package.json**:
```json
//...
"dependencies": {
//...
"core-js": "^0.0.1"
//...
}
```
- Importar el módulo **RentaModule** en el **AppModule** o en la **clase Module** dónde se vaya a utilizar:

```javascript
    (...)
    import { RentaModule } from 'projects/renta/src/lib/renta.module';

    @NgModule({
      (...)
      imports: [
        (...)
        RentaModule
      ],
      (...)
    })
    export class AppModule { }
```

### Componentes
#### lib-cabecera-renta
- Componente que contiene la cabecera a utilizar por los proyectos de RENTA 2019, tiene las siguientes propiedades:
**1.** **nombreContribuyente**: Es una propiedad de entrada de tipo string. Es el nombre del contribuyente el cuál se mostrará como parte de la cabecera.
**2.** **paso**: Es una propiedad de entrada de tipo number. Es el paso de la declaración en el cuál se encuentra el contribuyente, y sirve para que se muestre en el tracking bar. Puede tener los siguientes valores:
1 = Complete
2 = Presente/Pague
3 = Constancia
**3.** **eventoSalir**: Es una propiedad de salida. Evento que se lanza al presionar el boton **salir**.
- Ejemplo:
```html
<lib-cabecera-renta [nombreContribuyente]="'UNION DE CERVECERIAS PERUANAS BACKUS Y JHONSTON S.A.C.'" [paso]="2" (eventoSalir)="salir()"></lib-cabecera-renta>
```
#### lib-casilla-renta
- Componente que contiene las casillas a utilizar por los proyectos de RENTA 2019, tiene las siguientes propiedades:
**1.** **tipo**: Es una propiedad de entrada de tipo number. Indica el tipo de casilla que se desea utilizar, puede tener los siguientes valores:
0 = Casilla de monto.
1 = Casilla calculada.
2 = Casilla con asistente.
**2.** **numCasilla**: Es una propiedad de entrada de tipo string. Es el número de la casilla. Si no se envía no se muestra el número de casilla.
**3.** **textoPopover**: Es una propiedad de entrada de tipo string. Es el texto que se mostrará al precionar el popover de la casilla. Si no se envía no se muestra el popover de la casilla.
**4.** **abrirAsistente**: Es una propiedad de salida. Evento que se lanza al hacer click en la casilla. ***Sólo se lanza si el tipo de casilla es 2.***
**5.** **monto**: Es una propiedad de entrada y salida de tipo number. Es el valor de la casilla.
- Ejemplo:
```html
<lib-casilla-renta [tipo]="2" (abrirAsistente)="abrirAsistente()" [(monto)]="objetoPrb.monto" [numCasilla]="objetoPrb.numeroCasilla" [textoPopover]="objetoPrb.textoCasilla"></lib-casilla-renta>
```


**Indice**

[TOCM]

[TOC]
